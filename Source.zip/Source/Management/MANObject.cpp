// Fill out your copyright notice in the Description page of Project Settings.


#include "MANObject.h"

void MANObject::SetBoundActor(AActor* actor)
{
	boundActor = actor;
}
