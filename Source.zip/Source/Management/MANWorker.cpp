	// Fill out your copyright notice in the Description page of Project Settings.


	#include "MANWorker.h"

	#include "Worker.h"

	void MANWorker::Debug(const std::string& message) const
	{
		if (boundActor)
			Cast<AWorker>(boundActor)->DebugMessage(message.c_str());
	}

	void MANWorker::Init(AActor* actor)
	{
		SetBoundActor(actor);
	}
