#include "FirstWorker.h"

void FirstWorker::Update()
{
}

void FirstWorker::Begin()
{
}
