#pragma once
#include <MANWorker.h>

class FirstWorker : public MANWorker
{
public:
	FirstWorker() = default;
	~FirstWorker() = default;

	void Update() override;
	void Begin() override;

};

CREATE_WORKER(FirstWorker, CreateUserCode)