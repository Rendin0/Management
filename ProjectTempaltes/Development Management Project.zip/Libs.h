#pragma once
#if defined (UE_DEV)
	#pragma comment(lib, "UnrealEditor-Management.lib")
	#pragma comment(lib, "UnrealEditor-Management.sup.lib")
#elif defined (DEV)
	#pragma comment(lib, "Management.lib")
#elif defined(SHIPPING)
	#pragma comment(lib, "Shipping-Management.lib")
#else
	#error "At least one type of libs should be defined (UE_DEV, DEV, SHIPPING)"
#endif